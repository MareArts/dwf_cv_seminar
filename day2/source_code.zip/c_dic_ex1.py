
dic_a={}

dic_a['name'] = 'leon'
dic_a['hansome'] = 'yes'
dic_a['where'] = 'espoo'
print(dic_a)


dic_a={'name':'leon', 'hansome':'no'}
print(dic_a)

#add item
dic_a['good guy']='yes'
#modify item
dic_a['hansome']='yes'
print(dic_a)


