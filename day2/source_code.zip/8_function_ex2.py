

import day2.8_function_ex3 as lib 
print(lib.A_fun(1,2))
print(lib.B_fun(1,2))
print(lib.C_fun(1,2))



from day2.8_function_ex3 import A_fun
print(A_fun(1,2))


from day2.8_function_ex3 import B_fun
print(B_fun(1,2))


from day2.8_function_ex3 import C_fun as cfun
print(cfun(1,2))


