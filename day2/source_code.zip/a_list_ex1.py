
#list, tuple, dic

#list basic
list_a = [1, 2, 3, 4, 3]
print(list_a)

list_b = [[1, 2, 3, 4], [5, 6, 7, 8], [1, 2, 3, 4]]
print(list_b)

list_c = [[1, 2], [3, 4, 5], [6, 7, 8, 9]]
print(list_c)

list_d = ['a', 'bc', 'def', 'ddd', 'ddd']
list_e = [['a', 'bc', 12], [1, 2, 'abc', 2.33]]
print(list_d, list_e)


list_a = []
list_a.append('a')
list_a.append('b')
list_a.append('c')
print(list_a)

list_b=[]
list_b.append(list_a)
list_b.append([1, 2, 'b'])
print(list_b)











