
def A_fun(a,b):
    return a*2, b*2

def B_fun(a,b):
    return a*3, b*3

def C_fun(a,b):
    return a*4, b*4



def C_fasdfasdfasdfsafasdfsadfdsafun(a,b):
    return a*4, b*4

