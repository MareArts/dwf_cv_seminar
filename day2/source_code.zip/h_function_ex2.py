
import day2.h_function_ex3 as lib



import day2.h_function_ex3 as lib 
print(lib.A_fun(1,2))
print(lib.B_fun(1,2))
print(lib.C_fun(1,2))



from day2.h_function_ex3 import A_fun
print(A_fun(1,2))


from day2.h_function_ex3 import B_fun
print(B_fun(1,2))


from day2.h_function_ex3 import C_fasdfasdfasdfsafasdfsadfdsafun as shortf
print(shortf(1,2))


