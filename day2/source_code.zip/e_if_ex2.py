
if 1:
    print('true')

if 0:
    print('true')

if -1:
    print('true or flase')




#only 0 is false