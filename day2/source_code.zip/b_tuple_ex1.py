
tuple_a = (1, 2)
tuple_b = (1, 2, 3)
print(tuple_a)
print(tuple_b)


tuple_a = ((1,2,3), (1,2))
print(tuple_a)

tuple_a = ((1,2,3), ('1','2'))
print(tuple_a)
print(tuple_a[0])


list_a=[1, 2, 3]
tuple_a=(1, 2, 3)

list_a[0] = 10
print(list_a)
#tuple_a[0] = 10 #error

tuple_a[0] = 10

list_a.append('5')
tuple_a.append(3) #error





