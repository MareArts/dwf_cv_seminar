


for i in range(0, 10):
    print(i)


for i in range(0,10,2):
    print(i)


list_a = [1, 2, 'a', 3, 'b']
for item in list_a:
    print(item)


#########################



for i in range(1,10):
    for j in range(1,10):
        print(i,j)


for i in range(1,10):
    for j in range(1, 10):
        for k in range(1,10):
            print(i,j,k)


list_a = [ [1, 2, 3], [4, 5, 6] ]
for i in list_a:
    print(i)
    for j in i:
        print(j)


#################################

list_b = ['a', 'b', 'c']
for i, v in enumerate(list_b):
    print(i,v)






