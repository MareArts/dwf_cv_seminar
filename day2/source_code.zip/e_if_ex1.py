

a = 10


if a == 5:
    print('a is 5')

if a != 5:
    print('a is not 5')

if a > 5:
    print('a is bigger then 5')

if a >= 5:
    print('a is 5 or bigger than 5')

if a==1 or a==2:
    print('a is 1 or 2')

if a>1 and a<20:
    print('a is bigger than 1 and smaller than 20')


if (a==1 or a==10) and a>5:
    print('a is 1 or 10 and a is bigger than 5')


if a > 100:
    print('a is bigger than 100')
elif a >=10:
    print('a is between 100 and 10')
else:
    print('a is smaller than 10')
