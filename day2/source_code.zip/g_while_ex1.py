

i = 1
while i < 6:
  print(i)
  i += 1 #i=i+1



while 1:
    i=i+1
    print(i)
    if i>10:
        break


